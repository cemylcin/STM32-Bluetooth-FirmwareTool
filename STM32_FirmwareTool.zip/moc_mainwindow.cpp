/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.8.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../mainwindow.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>

#include <QtCore/qtmochelpers.h>

#include <memory>


#include <QtCore/qxptype_traits.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.8.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {
struct qt_meta_tag_ZN10MainWindowE_t {};
} // unnamed namespace


#ifdef QT_MOC_HAS_STRINGDATA
static constexpr auto qt_meta_stringdata_ZN10MainWindowE = QtMocHelpers::stringData(
    "MainWindow",
    "sendData",
    "",
    "value",
    "portlariListele",
    "portBaglan",
    "UART_Receive",
    "UART_Transmit",
    "clearAll",
    "copyAll",
    "saveData",
    "eraseButton",
    "on_saveButton_2_clicked",
    "on_copyButton_2_clicked",
    "on_getCommandsButton_2_clicked",
    "on_getChipIDButton_2_clicked",
    "on_getVersionButton_2_clicked",
    "btnBootloader",
    "writeToSTM",
    "firmwareData",
    "firmwareButton_clicked",
    "autoScanPorts",
    "startScan",
    "bluetoothButtons",
    "sendBluetoothData",
    "initializeBL",
    "readBluetoothData",
    "data",
    "onBluetoothConnected",
    "onBluetoothDisconnected",
    "clearBluetoothRXTX",
    "getCommands",
    "getChipID",
    "getVersion",
    "firmwareEraseBluetooth",
    "firmwareFlashBluetooth",
    "writeFirmwareBluetooth",
    "showReadmeDialog",
    "animatedButton"
);
#else  // !QT_MOC_HAS_STRINGDATA
#error "qtmochelpers.h not found or too old."
#endif // !QT_MOC_HAS_STRINGDATA

Q_CONSTINIT static const uint qt_meta_data_ZN10MainWindowE[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
      34,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,  218,    2, 0x06,    1 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       4,    0,  221,    2, 0x08,    3 /* Private */,
       5,    0,  222,    2, 0x08,    4 /* Private */,
       6,    0,  223,    2, 0x08,    5 /* Private */,
       7,    0,  224,    2, 0x08,    6 /* Private */,
       8,    0,  225,    2, 0x08,    7 /* Private */,
       9,    0,  226,    2, 0x08,    8 /* Private */,
      10,    0,  227,    2, 0x08,    9 /* Private */,
      11,    0,  228,    2, 0x08,   10 /* Private */,
      12,    0,  229,    2, 0x08,   11 /* Private */,
      13,    0,  230,    2, 0x08,   12 /* Private */,
      14,    0,  231,    2, 0x08,   13 /* Private */,
      15,    0,  232,    2, 0x08,   14 /* Private */,
      16,    0,  233,    2, 0x08,   15 /* Private */,
      17,    0,  234,    2, 0x08,   16 /* Private */,
      18,    1,  235,    2, 0x08,   17 /* Private */,
      20,    0,  238,    2, 0x08,   19 /* Private */,
      21,    0,  239,    2, 0x08,   20 /* Private */,
      22,    0,  240,    2, 0x08,   21 /* Private */,
      23,    0,  241,    2, 0x08,   22 /* Private */,
      24,    0,  242,    2, 0x08,   23 /* Private */,
      25,    0,  243,    2, 0x08,   24 /* Private */,
      26,    1,  244,    2, 0x08,   25 /* Private */,
      28,    0,  247,    2, 0x08,   27 /* Private */,
      29,    0,  248,    2, 0x08,   28 /* Private */,
      30,    0,  249,    2, 0x08,   29 /* Private */,
      31,    0,  250,    2, 0x08,   30 /* Private */,
      32,    0,  251,    2, 0x08,   31 /* Private */,
      33,    0,  252,    2, 0x08,   32 /* Private */,
      34,    0,  253,    2, 0x08,   33 /* Private */,
      35,    0,  254,    2, 0x08,   34 /* Private */,
      36,    1,  255,    2, 0x08,   35 /* Private */,
      37,    0,  258,    2, 0x08,   37 /* Private */,
      38,    0,  259,    2, 0x08,   38 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::Double,    3,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QByteArray,   19,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QByteArray,   27,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QByteArray,   27,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_ZN10MainWindowE.offsetsAndSizes,
    qt_meta_data_ZN10MainWindowE,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_tag_ZN10MainWindowE_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>,
        // method 'sendData'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        // method 'portlariListele'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'portBaglan'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'UART_Receive'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'UART_Transmit'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'clearAll'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'copyAll'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'saveData'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'eraseButton'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_saveButton_2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_copyButton_2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_getCommandsButton_2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_getChipIDButton_2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_getVersionButton_2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'btnBootloader'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'writeToSTM'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QByteArray, std::false_type>,
        // method 'firmwareButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'autoScanPorts'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'startScan'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'bluetoothButtons'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'sendBluetoothData'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'initializeBL'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'readBluetoothData'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QByteArray, std::false_type>,
        // method 'onBluetoothConnected'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onBluetoothDisconnected'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'clearBluetoothRXTX'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'getCommands'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'getChipID'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'getVersion'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'firmwareEraseBluetooth'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'firmwareFlashBluetooth'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'writeFirmwareBluetooth'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QByteArray, std::false_type>,
        // method 'showReadmeDialog'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'animatedButton'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    auto *_t = static_cast<MainWindow *>(_o);
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: _t->sendData((*reinterpret_cast< std::add_pointer_t<double>>(_a[1]))); break;
        case 1: _t->portlariListele(); break;
        case 2: _t->portBaglan(); break;
        case 3: _t->UART_Receive(); break;
        case 4: _t->UART_Transmit(); break;
        case 5: _t->clearAll(); break;
        case 6: _t->copyAll(); break;
        case 7: _t->saveData(); break;
        case 8: _t->eraseButton(); break;
        case 9: _t->on_saveButton_2_clicked(); break;
        case 10: _t->on_copyButton_2_clicked(); break;
        case 11: _t->on_getCommandsButton_2_clicked(); break;
        case 12: _t->on_getChipIDButton_2_clicked(); break;
        case 13: _t->on_getVersionButton_2_clicked(); break;
        case 14: _t->btnBootloader(); break;
        case 15: _t->writeToSTM((*reinterpret_cast< std::add_pointer_t<QByteArray>>(_a[1]))); break;
        case 16: _t->firmwareButton_clicked(); break;
        case 17: _t->autoScanPorts(); break;
        case 18: _t->startScan(); break;
        case 19: _t->bluetoothButtons(); break;
        case 20: _t->sendBluetoothData(); break;
        case 21: _t->initializeBL(); break;
        case 22: _t->readBluetoothData((*reinterpret_cast< std::add_pointer_t<QByteArray>>(_a[1]))); break;
        case 23: _t->onBluetoothConnected(); break;
        case 24: _t->onBluetoothDisconnected(); break;
        case 25: _t->clearBluetoothRXTX(); break;
        case 26: _t->getCommands(); break;
        case 27: _t->getChipID(); break;
        case 28: _t->getVersion(); break;
        case 29: _t->firmwareEraseBluetooth(); break;
        case 30: _t->firmwareFlashBluetooth(); break;
        case 31: _t->writeFirmwareBluetooth((*reinterpret_cast< std::add_pointer_t<QByteArray>>(_a[1]))); break;
        case 32: _t->showReadmeDialog(); break;
        case 33: _t->animatedButton(); break;
        default: ;
        }
    }
    if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _q_method_type = void (MainWindow::*)(double );
            if (_q_method_type _q_method = &MainWindow::sendData; *reinterpret_cast<_q_method_type *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_ZN10MainWindowE.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 34)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 34;
    }
    if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 34)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 34;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::sendData(double _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_WARNING_POP
